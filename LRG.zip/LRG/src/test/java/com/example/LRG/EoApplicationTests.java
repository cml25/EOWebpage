package com.example.LRG;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EoApplicationTests {

	@Test
	void contextLoads() {
	}

}
