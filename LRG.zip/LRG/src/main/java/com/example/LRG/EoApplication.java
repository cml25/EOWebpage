package com.example.LRG;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EoApplication.class, args);
	}

}
